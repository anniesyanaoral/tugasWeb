-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2017 at 08:23 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `data_rs`
--
CREATE DATABASE IF NOT EXISTS `data_rs` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `data_rs`;

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
  `nama` varchar(25) NOT NULL,
  `alamat` varchar(25) NOT NULL,
  `no_telp` char(25) NOT NULL,
  `no_antri` char(25) NOT NULL,
  `diagnosa` varchar(25) NOT NULL,
  `dokter` varchar(25) NOT NULL,
  PRIMARY KEY (`no_antri`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`nama`, `alamat`, `no_telp`, `no_antri`, `diagnosa`, `dokter`) VALUES
('dina', 'Jl.Mangga', '0987654356765', '01', 'Diare', 'Daeng'),
('tina', 'jl.jambu', '087533235465', '02', 'flu', 'menik'),
('fani', 'jl.cengkeh', '087564267543', '03', 'batuk', 'rafi'),
('tere', 'jl.jeruk', '09807654876', '04', 'muntaber', 'tika'),
('umi', 'jl.durian', '087654567876', '05', 'db', 'gigih');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
